/*************************************
* Programmer: Craig Wiencek
* classID: cwienc5421
* Fall 2016
* Date completed: 11/6/16
**************************************
This purpose of this application is to sort an array of integers that are determined
by user input. The sorting is done by using a bubble sorting algorithm inside of
a if statement that is nested within two "for" loops.
**************************************/

//On to the coding!!!


package bubble.sort;

/**
 *
 * @author Craig
 */import java.util.*;

public class BubbleSortDemo {

    public static void main(String[] args) {
    int[] someNums=new int[5];
    int a, b, temp;
    int comparisonTable=someNums.length-1;
    Scanner keyboard=new Scanner(System.in);  
    
    for(a = 0; a < someNums.length; ++a){
        System.out.print("Enter number " + (a+1) + " >> ");
        someNums[a]=keyboard.nextInt();
    }
    
    display(someNums, 0);
    
    for(a=0; a < someNums.length-1; ++a){
        for(b=0; b < comparisonTable; ++b){
            if(someNums[b] > someNums[b+1]){
                temp=someNums[b];
                someNums[b]=someNums[b+1];
                someNums[b+1]=temp;
            }
        }display(someNums, (a+1));
        --comparisonTable;
    }
    
   
    
    }
    
    public static void display(int[] someNums, int a){
        System.out.print("Iteration " + a + " : ");
        for(int x=0; x<someNums.length; ++x)
           System.out.print(someNums[x] + " ");
            System.out.println();
        
    }
    
}