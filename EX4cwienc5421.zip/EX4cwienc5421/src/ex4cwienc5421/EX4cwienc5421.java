/*************************************
* Programmer: Craig Wiencek
* classID: cwienc5421
* Lecture11: Welcome to Java
* CIS 2600: Business Application Programming
* Fall 2016
* Due date: 11/03/16
* Date completed: 11/02/16
**************************************
This program was written to declare 15 array elements in an array. Then to display
* the elements in descending order then ascending order.
**************************************/

//On to the coding!!!


package ex4cwienc5421;


/*Class EX4cwienc5421 is public and the only class present in this project*/
public class EX4cwienc5421 {
    

    /*the main is public and doesn't require another object to run so it is static
     and does not return a value so it is void.
     */
    public static void main(String[] args) {
/*I named my integer array numberOfLives and initialized the 15 elements in curly
        braces. I then set the control value of integer MIN_ARRAY_VALUE to negitive
        one for when i want the array elements to order in decending value*/        
        int[] numberOfLives= {000,100,200,300,400,500,600,700,800,900,1000,1100, 
            1200,1300,1400};
        int MIN_ARRAY_VALUE= -1;
        
System.out.println("=====================================================");      
System.out.println("First let's display array numbers in descending order:");
System.out.println("=====================================================");
System.out.println("=====================================================");

/*Here is my basic for loop, declaring the integer variable "control" as 14 inside
the for loop which will be our test value. Creating the test portion of the loop
i created it to run as long as the variable control is greater than MIN_ARRAY_VALUE.
After each test control decreases by one, when -- is placed before the variable
the variable is decreased then compared. */
        for(int control= 14; control>MIN_ARRAY_VALUE; --control)
        {
/*This print line will run as long as control>MIN_ARRAY_VALUE holds true and for 
  each time it is ran control is decreased by one so the array element called from
  numberOfLives will decrement respectively.*/            
         System.out.println(numberOfLives[control]);  
        }
System.out.println("=====================================================");
System.out.println("=====================================================");
System.out.println("Now let's display them in ascending order");
System.out.println("=====================================================");
System.out.println("=====================================================");

/*This enhanced for loop runs with out stating or knowing the starting and ending
value. The variable enhancedControl takes on the number of elements in 
array numberOfLives so when it is called in the println method it is looped 
as many times of elements in array numberOfLives*/
        for(int enhancedControl : numberOfLives )
        {
         System.out.println(enhancedControl);   
            
        }
    System.out.println("=====================================================");
}
    
    
}
