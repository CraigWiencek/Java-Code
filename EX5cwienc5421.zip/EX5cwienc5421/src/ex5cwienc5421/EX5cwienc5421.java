/*************************************
* Programmer: Craig Wiencek
* classID: cwienc5421
* Lecture11: Welcome to Java
* CIS 2600: Business Application Programming
* Fall 2016
* Due date: 12/03/16
* Date completed: 12/01/16
**************************************
This program is meant to collect customer's ID, first name, last name, and the 
balance they owe. Their entry is then entered into text document named 
Customer.List.txt
**************************************/

//On to the coding!!!


package ex5cwienc5421;

/*Import of multiple java classes. util wildcard for scanner that enables user
input.  nio.file wild card to enable new input and outputs to a file.  
nio.file.StandardOpenOperation wild card for opening and closing files. */
import java.util.*;
import java.nio.file.*;
import java.io.*;
import static java.nio.file.StandardOpenOption.*;
public class EX5cwienc5421 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
/*Used the Path class to get the relative file path to CustomerList.txt inside 
EX5cwienc5421 folder, i named the object cusFile. Object input is set to Scanner
for user input. String cust is used to construct a string that holds
customer information and delimiters to to display customer records in CustomerList.txt
as comma-seperated values. */        
        Path cusFile = Paths.get("CustomerList.txt");
        Scanner input = new Scanner(System.in);
        String cust="";
        int cusID=0;
        String fName="";
        String lName="";
        double amntOwed=0.0;
        String delimiter=",";
        final int QUIT=999;

        
/*Operations are held within this try block so we can catch exceptions that may 
        occur*/        
try{
           System.out.print("Please enter customer ID >> ");
        cusID=input.nextInt();    

/*Object output is set to create a newOutputStream from the files class, which 
is the class that enables files to be modified, and takes in the cusFile object
that holds the relative path to the file, and CREATE which opens  the file if it
exists or creates it if file isn't found. All of which is the sent in a of
a BufferedOutPutStream. Object writer is set to take object output and
create a new OutPutStreamWriter each time the loop is executed which is why it
enables the entry of multiple customer records.*/        
    OutputStream output = new BufferedOutputStream(Files.newOutputStream(cusFile, CREATE));
         BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(output));
  while(cusID!=QUIT){  
 

/*After the user is prompted for the customers first name, we enter in
input.nextLine() to clear the buffer then set the variable fName to hold the user
entry*/      
        System.out.print("Please enter customer first name >> ");
        input.nextLine();  
        fName=input.nextLine();
        System.out.print("Please enter customer last name >> ");
        lName=input.nextLine();
        System.out.print("Please enter amount owed >> ");
        amntOwed=input.nextDouble();

/*cust string now is set to hold all of a customers information, with a delimiter
  declared as a comma to seperate fields*/        
        cust = cusID + delimiter + fName + delimiter + lName + delimiter + amntOwed;
/*The object writer now uses the write() from the files class, it takes in the
  string cust, and writes every character in the string starting at point zero 
  and ending at the lenght of the string which is counted in characters.*/        
        writer.write(cust, 0, cust.length());
        writer.newLine();
        System.out.print("Please enter customer ID or "+ QUIT+" to QUIT>> ");
        cusID=input.nextInt();
        
} 
  
/*Once the user enters 999 (QUIT) the loop is exited and object writer is closed.*/  
  writer.close();
}

/*If the user enters an exception in the try block a message will display on the
command line stating what kind of exception it is.*/
catch(Exception a){
    System.out.print("Message: "+a);
    }
    
    }
}
