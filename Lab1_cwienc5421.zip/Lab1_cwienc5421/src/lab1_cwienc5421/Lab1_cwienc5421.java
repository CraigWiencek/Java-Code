/*************************************
* Programmer: Craig Wiencek
* classID: cwienc5421
* Lecture11: Welcome to Java
* CIS 2600: Business Application Programming
* Fall 2016
* Due date: 10/06/16
* Date completed: 10/06/16
**************************************
This programs essential function is to enable a store owner to calculate the cost
* of their product by entering in their cost of materials and number of labor
* hours. I wrote this code in such a way that it utilizes command line functions
* as well as GUI dialog boxes. I utilized command line functions to represent a 
* receipt of sorts so the user can see each bit of information they have entered
* into the system and for which product. The GUI prompts are used to tell/ask the
* user what information is required. I have successfully constructed this code 
* to calculate the price for more than one item while keeping the price of
* shipping and handling the same. If you wish to calculate the price for only one
* item please enter zero for item two's price of materials and labor hours.

*/


package lab1_cwienc5421;

/**This tells java to import the JOptionPane class that I'll be using which is
 * found in javax.swing.*/
import javax.swing.JOptionPane;

/**
 * "public" is the access specifier specifying everyone has access to the 
 * program. The object "class" specifies the file Lab1cwienc5421 is the name of 
 * the class.
 * @author Craig
 */
public class Lab1_cwienc5421 {

     /** Again public is the access specifier meaning it has potential to be
     * accessed by everyone. "Static" modifies access to work without instantiating 
     * an object of the class. "Void" simply means the method does not return 
     * any values.
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /**Here I display the name of my business in the command line in the ASCII
      design of my choice using system.out.println to specify that each entry 
      has its own line. I broke up the message using the '\n' code for new/next
      line.*/   
         System.out.println("==========================="
              + "==================================");
      System.out.print("Hello and welcome to Zion Consulting! We are here"
            + " to consult \nyou through all of your assembly needs.");  
      System.out.println("\n==========================="
              + "=================================="); 
      
        
       /**Here is where my first GUI box is initiated. I specifically chose a
        .showMessageDialog GUI to welcome instead of requesting their information
        right off the bat. */       
      JOptionPane.showMessageDialog(null, "We will start by asking the name of the "
              + "product you would like to create.");
     
      
      /**Here i call up my method that is found at the bottom of the page.
       I made sure to build the method outside of the main method because you 
       cannot have a method built within another method.*/
        displayProductEntryInformation();
    }
 /**Here is method productEntryInformation(), "static" stating that it does not 
    require an object and in stating that the method productOneEntry() is a 
    integer. Notice that void is absent because this method does return
    a value.*/
    static int displayProductEntryInformation(){
        /**Here i declared variables material and labor are doubles and that
        they are set to start at zero*/
      double material = 0;
      double labor = 0;
      
       
      /**I started by stating that the JOptionPane is going to be a "String" and 
       that it will be called "productOneName". I made this a .showInputDialog so
       that the user can input their products name directly into the GUI box and
       have it displayed in the command line using System.out.println. I figured
       I could make this application more official by entering a third argument
       "Name of Product" which will be displayed in the user's GUI data input
       box.*/
      String productOneName;
      productOneName=JOptionPane.showInputDialog(null, "Please enter product name", 
              "Name of Product");
      System.out.println("Product: " + productOneName);
          
      /**This JOptionPane is to inform the user as to what 
       information they are going to have to provide next. Using
       showMessageDialog doesn't request any information from the user,
       simply to display a informative GUI.*/
      JOptionPane.showMessageDialog(null, "Fantastic! The next bit of information " +
              "we require is the \namount of money you intend on spending" +
              " on materials and \nthe number of labor hours you intend to " +
              "spend on your project.");
      
      /**The next two strings are materialCost and laborHours and they are both
       JoptionPane.showInputDialog GUI's so the user can enter the cost of their
       materials and labor. System.out.println will be used to display entries
       in the command line. Since the variable material has already been declared
       as a double, the value of material can be displayed with correct
       concatenation. material=Double.parseDouble(materialCost) must be included
       inorder to have the value of materials displayed correctly in the command 
       line. 
       */
      String materialCost;
      materialCost=JOptionPane.showInputDialog(null, "Please enter your material"
              + " cost.", "Cost of Material");
      material=Double.parseDouble(materialCost);
           System.out.println("Material cost: $" + material);

      
      String laborHours;
      laborHours=JOptionPane.showInputDialog(null, "Please enter your labor hours."
              + "\n(as a whole number)", "Labor Hours");
      labor=Double.parseDouble(laborHours);
           System.out.println("Hours of labor required: " + laborHours + " hours");
        
      /**This was made to display in the command line so the user can see their 
       total and for which product. And since variables material and labor were
       declared earlier and their values have been entered in by the user
       the calculation can be executed here.*/    
      System.out.println("Your total for " + productOneName + " before shipping and "
              + "handling is: $" + (material + (12 * labor)));
       /**Here is where i state that this method is a return method so it can
        be called in the main() method*/ 
       
       System.out.println("===============================");
       

      
      /**Here is where the user gets confronted with a YES/NO showConfirmDialog
       * GUI asking if they would like to add another item to their cart.  */
      JOptionPane.showConfirmDialog(null, "Would you like to add another item to"
              + " your cart?", "chose", JOptionPane.YES_NO_OPTION);{
        
      /**Here i declared the variable 'choice' is a integer which i used in my
       nested 'if' methods which are dependent on whether if the user chooses
       yes or no to add another item.*/  
      
      int choice = 0;
      //int additionalItem = 0;
      //boolean isYes;
      //boolean isNo;
      
        
     //switch(additionalItem){
      //case 1:
          //isYes = (choice==JOptionPane.YES_OPTION);
      
    /**This is my first 'if' statement. The 'YES_OPTION' argument specifies that
     if the user selects yes in the JOptionPane for adding an additional item it
     * will bring the next line of code here to read the following lines of code.*/
      if(choice==JOptionPane.YES_OPTION)
      
      {
        /**This is the prompt of strings that will be ran if the user selects yes
         to add another item. I named the strings productTwoName, 
         secondMaterialCost, and secondLaborHours to differentiate from the first
         products values/variables. The second products name, material cost, and
         labor hours are all entered in by the user via showInputDialog GUI's
         and all three values are displayed in the command line for the users
         review.*/  
      String productTwoName;
      productTwoName=JOptionPane.showInputDialog(null, "Please enter product name", 
              "(null)");
            System.out.println("Product: " + productTwoName);
          double secondMaterial = 0;
          double secondLabor = 0;
      
      String secondMaterialCost;
      secondMaterialCost=JOptionPane.showInputDialog(null, "Please enter your material"
              + " cost.", "Cost of Material");
      secondMaterial=Double.parseDouble(secondMaterialCost);
                 System.out.println("Material cost: $" + secondMaterial);

      
      String secondLaborHours;
      secondLaborHours=JOptionPane.showInputDialog(null, "Please enter your labor hours."
              + "\n(as a whole number)", "Labor Hours");
      secondLabor=Double.parseDouble(secondLaborHours);
      
      System.out.println("Hours of labor required: " + secondLaborHours + " hours");

      System.out.printf("Your total for " + productTwoName +" before shipping"
              + " and handling is: $" +
                  (secondMaterial + (12 * secondLabor)));
      
      /**Here i declare the sum of product one and product two are doubles. Using
       the previously declared variables (material, labor, secondMaterial, and 
       secondLabor) and some simple arithmetic i was able to create a third
       variable (grandTotal) to hold the value of both products plus shipping 
       and handling. JOptionPane.showMessageDialog is prompted to display the 
       final total of both products to the user.*/
      double productOneSum = material + (12*labor);
      double productTwoSum = secondMaterial + (12*secondLabor);
      double grandTotal= productOneSum + productTwoSum + 7;
      JOptionPane.showMessageDialog(null,"The total for items " + productOneName +
              " and " + productTwoName + " after shipping and handling is: $" + 
              grandTotal);
      
       System.out.println("\n==========================="
               + "==================================");    
      }
     // break;
      
     //case 2:
      //isNo = (choice==JOptionPane.NO_OPTION);
      
      
      /**If the user selects no for their option to add another item then this
       is the next lines of java that will be read. This bit of code omits all the
       information pertaining to product two and only displays product one info. */
      else if(choice==JOptionPane.NO_OPTION){
       
      double productOneSum = material + (12*labor);
      double grandTotal= productOneSum + 7;
      JOptionPane.showMessageDialog(null,"The total for item " + productOneName +
                " after shipping and handling is: $" + grandTotal);
      
       System.out.println("==========================="
               + "==================================");            
      }
     // break;
           
               }
    /**Here is my return statement that returns the values of method
     * displayProductInfrormation to the main method */          
              return 1;
}
            
     
}
