/*************************************
* Programmer: Craig Wiencek
* classID: cwienc5421
* Lecture11: Welcome to Java
* CIS 2600: Business Application Programming
* Fall 2016
* Due date: 10/27/16
* Date completed: 10/26/16
**************************************
* Program Explanation: The purpose of this program is to prompt the user(cashier)
* to enter an invoice number within a specified value range, enter a item name
* from a specified list, and enter item cost that must be greater than zero. This
* is all executed through command line statements entered in CreatePurchase class
* and sent to the Purchase class.
* 
 */
package lab2cwienc5421;

//Here is the importing of the java utility scanner that allows user input
import java.util.Scanner;



public class CreatePurchasecwienc5421
{

   public static void main (String args[])
   {
/*Here the getSalesIinfo method is called as well as the showSalesReceipt method. 
 Notice showSalesReceipt has cashierEntry in its parenthesis and that class
 Purchasecwienc5421 is associated with cashierEntry, this way the method
 showSalesReceipt brings the info from Purchasecwienc5421 class*/
     Purchasecwienc5421 cashierEntry;
     cashierEntry = getSalesInfo();
     showSalesReceipt(cashierEntry);
   }

   public static Purchasecwienc5421 getSalesInfo()
   {
      Purchasecwienc5421 newSale = new Purchasecwienc5421();
      
      String itemEntryName;
      int invoiceEntryNumber=0;
      double saleEntryAmount=0;
      String skateboard="";
      String shoes="";
      String wheels="";
      String bearings="";
      String hardware="";

/*Here I implemented the java utility scanner to allow for user input on the 
      command line.*/      
      Scanner input = new Scanner(System.in);
      
/*Thesse three print methods are the initial prompts to ask the user for input
 data and each input that the user enters in command line is assigned a unique
 vairable that is declared above. The varable is placed within the parenthesis
 of the respective method it gets sent to in the Purchase class.*/      
      System.out.print("Please enter invoice number>> ");
      invoiceEntryNumber=input.nextInt();
      newSale.setInvoiceNumber(invoiceEntryNumber);
      
      
      System.out.print("Please enter product name>> ");
      itemEntryName=input.next();
      newSale.setItemName(itemEntryName);
      
      
      System.out.print("Please enter sales amount>> ");
      saleEntryAmount=input.nextDouble();
      newSale.setSaleAmount(saleEntryAmount);

/*Since this method returns a variety of varables to specific methods in the 
Purhcase class, I had to place this return statement and gave it the name newSale*/     
      return newSale;
   }


   /*I created a seperate method for providing the sales reciept, it is comptised of 
   println, print and printf methods. The name of the business and address are 
   displayed in ASCII form. Each method found in the Purchase class pertaining to 
   the invoice number, item name, and sale amount are called in this method and 
   displayed in the command line. To calculate sales tax i created a final double 
   variable named TAX_VALUE and set it to the equivalence of 5% and created a 
   seperate printf method to display the getSalesAmount() value and multiply it
   by the constant.*/
   public static void showSalesReceipt(Purchasecwienc5421 saleInfo)
   {      final double TAX_VALUE=0.05;

       System.out.println("=====================================================");
    System.out.println("\nRelic Skateboards Invoice");
    System.out.println("\n714 DogTown Avenue, San Clemente, CA");
    System.out.println("\n=====================================================");
    System.out.println("\nInvoice #" + saleInfo.getInvoiceNumber());
    System.out.print("\nName of Product: " + saleInfo.getItemName());
    System.out.printf("\nItem cost: $" + saleInfo.getSalesAmount());
    System.out.printf("\nSales tax: $" + saleInfo.getSalesAmount()*TAX_VALUE);
    System.out.println("\n=====================================================");
   }
}
