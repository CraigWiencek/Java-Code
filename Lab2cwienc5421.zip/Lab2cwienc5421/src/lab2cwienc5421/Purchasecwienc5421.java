/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2cwienc5421;

/**
 *
 * @author Craig
 */

/*Again here i import the java utility scanner so the user can re-input information
if their input does not satisfy the parameters of my if or while statements*/
import java.util.Scanner;


public class Purchasecwienc5421
{ 
/*Here is the declaration of all the variables used in this class. Notice many are
set to private. This is so that they cannot be changed outside of this class.*/    
  private String finalItemName;
  private int invoiceNumber;
  private double finalSaleAmount;
  final int MIN_INVOICE_VALUE=1000;
  final int MAX_INVOICE_VALUE=8000;
  private String skateboard;
  private String shoes;
  private String wheels;
  private String bearings;
  private String hardware;
    
/*Here is the creation of my first method setInvoiceNumber(), notice that it is 
  non-static, that is because it requires an object which is invoiceEntryNumber
  from the CreatePurchase class. invoiceEntryNumber is declared as a int in the
  CreatePurchases class so it must be delcard as a int as the arguement for
  setInvoiceNumber method.*/  
public void setInvoiceNumber(int invoiceEntryNumber)
   {          Scanner input = new Scanner(System.in);

  /*This while statement was created to verify that invoiceEntryNumber is greater
   than MIN_INVOICE_VALUE which is a final int variable i declared to be 1000 or
   that invoice entry number is less than MAX_INVOICE_VALUE which is a final int
   variable i declared to be 8000. If the users entry doesent meet either of these
   requirements the System.out.print line i create will repeat until the parameters
   are met.*/  
       while(invoiceEntryNumber<MIN_INVOICE_VALUE || invoiceEntryNumber>MAX_INVOICE_VALUE)
       {
           System.out.print("You have entered an invalid invoice number. \nPlease"
        + " enter number between 1000 and 8000...>> ");
            invoiceEntryNumber = input.nextInt();

   }                 
   /*If the while statement is not triggered then invoiceEntryNumber is reassigned
       to the name invoiceNumber which is returned in the getInvoiceNumber method*/    
       invoiceNumber = invoiceEntryNumber;
   }
/*Here is the method i created to return invoiceNumber. Notice that it is a non-static
integer, because it requires a object and it returns an integer.*/
public int getInvoiceNumber()
   {
      return invoiceNumber;
   }
  
/*Notice this method is also a non-static, that is because it requires an object
but remains void because it doesent return a value. The method uses the arguemtent
itemEntryName which is a String*/
public void setItemName(String itemEntryName)
   {    
       
       Scanner input = new Scanner(System.in);
/*I implemented this switch statement to limit the item entry to five specific
items declared as strings. If itemEntryName meets one of the declared vairables
the program will continue to run as usual. If itemEntryName doesnt meet one declared
variables the default function will run prompting the user to re-enter their
item and list the possible item entries. At the end of each case and default
itemEntryName is reassigned the name finalItemName which is returned to the main()
in the getItemName method.
       */       

switch(itemEntryName){
case"skateboard": {
    itemEntryName=skateboard;
       finalItemName = itemEntryName;

break;
}
case"shoes":{
    itemEntryName=shoes;
       finalItemName = itemEntryName;

break;
}
case"wheels":{
    itemEntryName=wheels;
       finalItemName = itemEntryName;

break; 
}
case"hardware":{
    itemEntryName=hardware;
       finalItemName = itemEntryName;

break;
}
case"bearings":{
    itemEntryName=bearings;
       finalItemName = itemEntryName;

break;
}
default:
System.out.print("You have entered an invalid item. \nPlease"
        + " enter skateboard, shoes, wheels, bearings, or hardware>> ");
            itemEntryName=input.next();
                   finalItemName = itemEntryName;
            break;
}

    }

 
/*This method returns finalItemName. Notice it is non-static because it is requires
an object an void has be replaced with String because finalItemName is a string*/   
public String getItemName()
   { 
      return finalItemName;
   }
     
/*Here is the creation of my setSaleAmount method, notice it is non-static because it requires an 
object and void because it doesn't return a value. It requires the value of
saleEntryAmount that is a double and entrered in the CreatePruchase class by the user*/
public void setSaleAmount(double saleEntryAmount)
   {    Scanner input = new Scanner(System.in);
   
/*This while statement executes if the saleEntryAmount that the user enters is 
   less than one. A message is displayed to the user using print method then gives
   them the ability to re-enter the sales amount and will continue to until they
   meet the parameters set in the while statement.*/   
       while(saleEntryAmount<1)
       {System.out.print("\n You have entered a invalid sales amount. Please enter"
               + " amount greater than zero.");
       System.out.print("\nRe-enter sales amount>> ");
                    saleEntryAmount=input.nextDouble();

        }
/*This gives saleEntryAmount the new name finalSaleAmount which is returned in the
       getSalesAmount method*/
      finalSaleAmount = saleEntryAmount;
   }
/*This is the method that returns finalSaleAmoount. Notice the method getSalesAmount
is a non-static because it requires an object and that void is replaced with double
because the value it returns is a double.*/   
public double getSalesAmount()
   {
      return finalSaleAmount;
   }
  
}



