/*************************************
* Programmer: Craig Wiencek
* classID: cwienc5421
* Lecture11: Welcome to Java
* CIS 2600: Business Application Programming
* Fall 2016
* Due date: 12/09/16
* Date completed: 12/08/16
**************************************
This program is meant to collect students's WIN, first name, last name, and their
GPA. According to their GPA, the students record will either be entered into 
studentsgoodstanding.txt file or studentsacedemicprobation.txt file. Once the user
has finished entering student records and exits the loop, 2 list are displayed,
one of students who have a GPA equal to or below 2.0 and the other of students 
who have a GPA above 2.0.

*************************************/
package lab5cwienc5421;

/*Import of multiple java classes. util wildcard for scanner that enables user
input and many other utility class functions.  nio.file wild card to enable new 
input and outputs to a file. io.IOException is for the main class because it throws
an input/output exception. nio.file.StandardOpenOperation wild card for opening 
and creating files. */
import java.util.*;
import java.nio.file.*;
import java.io.*;
import java.io.IOException;
import java.util.InputMismatchException.*;
import static java.nio.file.StandardOpenOption.*;
public class Lab5cwienc5421 {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
/*Used the Path class to get the relative file path to StudentsGoodStanding.txt 
and StudentsAcademicProbation.txt and named the respective objects nonProb and 
prob. Object input is set to Scanner for user input. String student is used to 
construct a string that holds student information and delimiters to divide each 
student field in CustomerList.txt as comma-seperated values. String array 'array'
is used once data from the file is read and brought to the application to seperate
each of the four student fields.*/        
        Path nonProb = Paths.get("StudentsGoodStanding.txt");
        Path prob = Paths.get("StudentsAcademicProbation.txt");
        Scanner input = new Scanner(System.in);
        String student="";
        String delimiter=",";
        int WIN;
        String fName="";
        String lName="";
        double GPA=0.0;
        final double MIN_GPA=2.00;
        final int QUIT=666;
        String[] array=new String[4];
/* 4 objects are created below. output and outputProb is set to create a
newOutputStream from the files class, which is the class that enables files to be
modified, and the respecive object takes in nonProb object and prob object
that holds the relative path to each file and CREATE which opens the file if it
exists or creates it if file isn't found. All of which is the sent in a of
a BufferedOutputStream. Object writer and writerProb is set to take object output and
outputProb and create a new OutPutStreamWriter.*/        
    OutputStream output = new BufferedOutputStream(Files.newOutputStream(nonProb, CREATE, APPEND));
         BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(output)); 
         
OutputStream outputProb = new BufferedOutputStream(Files.newOutputStream(prob, CREATE, APPEND));
         BufferedWriter writerProb = new BufferedWriter(new OutputStreamWriter(outputProb)); 
        
System.out.print("\n============================================================");
System.out.print("\n ");
System.out.print("\n       WELCOME TO WMU'S STUDENT GPA RECORD BOOK");
System.out.print("\n ");
System.out.print("\n============================================================");        


/*User is prompted for student WIN in try block which has 2 catches set, one for
InputMistmatchExcepton which is caught when the variable WIN is assigned a value
other than a integer and a general exception for any other exceptions.*/
    try{      
    System.out.print("\nPlease enter student WIN >> ");
        WIN=input.nextInt();
           
       }
    
   catch(InputMismatchException a)
   {
       WIN=888;
   }
   catch(Exception b)
   {        
          WIN=999;
           
   }
       

/*do loop configured to repeat as long as the user doesnt exit the program*/    
  do{  
 
/*After the user is prompted for the students first name, 
input.nextLine() method executes to clear the buffer then the users entry sets the
variable fName*/      
try{        
        System.out.print("Please enter student first name >> ");
        input.nextLine();  
        fName=input.nextLine();
    }

catch(Exception x){System.out.print(x);}
        System.out.print("Please enter student last name >> ");
        lName=input.nextLine();

/*Try block holds the prompt for student gpa*/        
        try{        
        System.out.print("Please enter GPA >> ");
        GPA=input.nextDouble();
    }
 /*if vairable GPA is assigned anything other than a double, exception is thrown
        and the inputmismatch catch executes.*/       
catch(InputMismatchException d){
       
    GPA=3.5;
    
       }
//for any additional exceptions
catch(Exception f)
    {
      GPA=3.5;
    }

        
        
/*To have student data entered into the appropriate file i set 2 test conditions
 in a if and else if statement that compares the users entry of GPA to the cut-off
 GPA value*/        
if(GPA>=MIN_GPA){
        
/*student string now is set to hold all of a customers information, with a delimiter
  declared as a comma to seperate fields*/        
        student = WIN + delimiter + fName + delimiter + lName + delimiter + GPA;
/*The object writer now uses the write() from the files class, it takes in the
  string student, and writes every character in the string starting at point zero 
  and ending at the lenght of the string which is counted in characters. Since 
  this is the if condition for students with a gpa exceeding 2.0 we use writer
  object which is set to input data in StudentsGoodStanding.txt. writer.newLine()
  method leaves the current line in the file that the students record is entered
  on and begins on the next line so additional records can be entered*/        
        writer.write(student, 0, student.length());
        writer.newLine();
}

else if(GPA<MIN_GPA){
    
/*Since this if conditon is for gpa's falling short of 2.0 we use the object
 writerProb which is set to input data in StudentsAcademicProbation.txt. writer.newLine()
  method leaves the current line in the file that the students record is entered
  on and begins on the next line so additional records can be entered*/
    student = WIN + delimiter + fName + delimiter + lName + delimiter + GPA;
        writerProb.write(student, 0, student.length());
        writerProb.newLine();


}

/*We are reaching the end of the loop so we ask the user if they would like 
to quit the program by entering '666' or the can enter another student record.
*/
try{
        System.out.print("Please enter student WIN or "+ QUIT+" to QUIT>> ");
        WIN=input.nextInt();
    }
/*Inputmismatchexception catches exception when varible WIN is assigned anything
other than an int and the second catch is just another general exception catcher*/
    catch(InputMismatchException a)
    {
       
        WIN=999;
        ++WIN;
    }
    catch(Exception c){
     
        WIN=999;
        ++WIN;
    }
    







}while(WIN!=QUIT); 

/*Once the user enters 666 (QUIT) the loop is exited and object writer and 
  writerProb is closed.*/  
  writer.close();
  writerProb.close();

/*InputStream object nonProbList and probList is set to null so it can take on a InputSteam
  of object nonProb (StudentsGoodStanding.txt) and prob (StudentsAcademicProbation.txt).
  With nonProbList and probList holding the ability to stream their respective files, we create
  a new InputStreamReader to read nonProbList's and probList's stream and set the object 'reader'
  and 'readerProb' to be a BufferedReader of said stream and display the information in command 
  line upon calling*/  
  InputStream nonProbList = null;
nonProbList = Files.newInputStream(nonProb);
BufferedReader reader= new BufferedReader(new InputStreamReader(nonProbList));

InputStream probList = null;
probList = Files.newInputStream(prob);
BufferedReader readerProb = new BufferedReader(new InputStreamReader(probList));

        


/*String is set to null and set to read file StudentsGoodStanding.txt*/
String scholarStudents=null;
scholarStudents=reader.readLine();


/*Since the data read from the file will be brought into netbeans as a string
we need to divide the string into usable and individual fields. This is where
the String array 'array' we created comes in hand. the array is set to hold the 
entire line of data read from the file as a string but by using method split() we can specify
where to split the string and divided it into individual variables...i specified
to split it where ever it finds a comma, which is what delimiter is set to. fName
and lName are expected to be assigned strings so we are okay with directly assigning
those from 'array' but to asign WIN and GPA we need to parse the array elements
to a int and double respectively. After the  variables are printed out in command
line we set scholarStudents to read another line of StudentsGoodStanding.txt before
the loop reaches its ending curly brace and test its condition which is set to 
stop once scholarStudents doesn't hold the next student record because it must have
reached the end of the file or there is a spacial gap between reco*/
System.out.print("\n========== STUDENTS MEETING/EXCEEDING 2.0 GPA ==============");
System.out.print("\n============================================================");
    while(scholarStudents!=null){

        array=scholarStudents.split(delimiter);
        WIN = Integer.parseInt(array[0]);
        fName = array[1];
        lName = array[2];
        GPA = Double.parseDouble(array[3]);         
        double exceeding2pt0= GPA-2.00;
        exceeding2pt0=exceeding2pt0*100;
        exceeding2pt0=exceeding2pt0 + .5;
        exceeding2pt0=(int)exceeding2pt0;
        exceeding2pt0=exceeding2pt0/100;
        
System.out.printf("\nWIN # "+ WIN +"   "+ fName +"    " +lName +"     "+ GPA+"     "+ exceeding2pt0);
        scholarStudents=reader.readLine();
    }
System.out.print("\n ");
System.out.print("\n============================================================");
    



String probationStudents=null;
probationStudents=readerProb.readLine();

/*Data read from the file will be brought into netbeans as a string
we need to divide the string into usable and individual fields. We are able to
reuse String array 'array', the array is set to hold the 
entire line of data read from the file as a string and method split() is used to specify
where to split the string and divided it into individual variables. fName
and lName are expected to be assigned strings so we are okay with directly assigning
those from 'array' but to asign WIN and GPA we need to parse the array elements
to a int and double respectively. After the  variables are printed out in command
line we set probationStudents is set to read another line of StudentsAcademicProbation.txt
before the loop reaches its ending curly brace and test its condition which is set to 
stop once scholarStudents doesn't hold the next student record because it must have
reached the end of the file or there is a spacial gap between records*/
        
System.out.print("\n ");

System.out.print("\n============== STUDENTS BELOW 2.0 GPA ====================");
System.out.print("\n============================================================");
while(probationStudents!=null){

     array=probationStudents.split(delimiter);
        WIN = Integer.parseInt(array[0]);
        fName = array[1];
        lName = array[2];
        GPA = Double.parseDouble(array[3]);
         double shortOf=GPA-2.01;
         shortOf=shortOf*100;
         shortOf=shortOf+0.5;
         shortOf=(int)shortOf;
         shortOf=shortOf/100;
System.out.printf("\nWIN # "+ WIN +"   "+ fName +"    " +lName +"     "+ GPA+"     "+ shortOf);
     probationStudents=readerProb.readLine();
    }
System.out.print("\n ");
System.out.print("\n============================================================");
    
exitProgram();
}
 
public static void exitProgram(){
System.out.print("\n============================================================");
System.out.print("\n ");
System.out.print("\n                    END TRANSMISSION: ");
System.out.print("\n ");
System.out.print("\n============================================================");
 
 }   
    
    
}