/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realtimeclock;

import java.time.*;
/**
 *
 * @author Craig
 */
public class JavaClock {

    /**
     * @param args the command line arguments
     */
public static void main(String[] args) {
    LocalDateTime now;
    int nowSec;
    int prevSec=0;
        for(;;){
            now=LocalDateTime.now();
            nowSec=now.getSecond();
                 if(nowSec != prevSec){
                    System.out.println(now.getHour()+" : "+now.getMinute()+" : "+nowSec);
                    prevSec=nowSec;
                    }
                }
    }

    
}
