/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realtimeclock;

import java.time.*;
/**
 *
 * @author Craig
 */

public class JavaClock {

    /**
     * @param args the command line arguments
     */
public static void main(String[] args) {

//object now takes on the properties of java class LocalDateTime
//declaration of int variables nowSec and prevSec
    LocalDateTime now;
    int nowSec;
    int prevSec=0;

//for loop will continue to re-execute (infinite-loop) when ;; double semi-colons are placed
//in its parameters
        for(;;){
//object now is set to take on the local time of your system's clock by pairing LocalDateTime class with now()
//method using java dot syntax. Integer nowSec takes object 'now' and, again by using dot.syntax with getSecond()
//method, gets the seconds of the local time on your systems's clock
            now=LocalDateTime.now();
            nowSec=now.getSecond();

//as long as nowSec doesn't equal prevSec this if statement will run and continue to show
//updated time in command line.
                 if(nowSec != prevSec){
                    System.out.println(now.getHour()+" : "+now.getMinute()+" : "+nowSec);
                    prevSec=nowSec;
                    }
                }
    }

    
}
