/*************************************
* Programmer: Craig Wiencek
* classID: cwienc5421
* Lecture11: Welcome to Java
* CIS 2600: Business Application Programming
* Fall 2016
* Due date: 09/15/16
* Date completed: 09/10/16
**************************************
The purpose of this program was to build a two-dimensional array. It allows the 
* user to add increments of 1 to a specific row,column in the matrix. 
**************************************/

//On to the coding!!!

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package twodimensionalarray2;

/**
 *
 * @author Craig
 */
import java.util.Scanner;
public class TwoDimensionalArray2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
/*Here I am declaring my multi-dimensional array that will have 5 columns and 5
  rows, with the name count. I also initializing the java.util.scanner that will
  accept the users data entry in the command-line interface. I declared variables
  row and column to be integers and assigned the final int QUIT the value 99 to be
  used as an escape for the user.
  */        
    int[][]count=new int[5][5];
    Scanner input=new Scanner(System.in);
    int row, column;
    final int QUIT=99;
 /*Using the print method here I am asking the user to either enter a row or 
    enter '99' to quit. If the user enters anything other than '99' the vaue will
    be assigned to variable 'row'*/        
        System.out.print("Enter a row or " + QUIT + " to quit >> ");
        row=input.nextInt();
/*I created this 'while' to continue until the user enters the 'QUIT' value. The
  print method prompts the user to enter a column. The conditions i put into the 
  if statemnt are set to have 'if' run aslong as the value the user set to row 
  less than the number of elements in the count array AND if the column value the user
  entered is less than the array element location that is equivalent to row value. The
  resulting action of the if statement will add one value/memory-space to row and column 
  in the count array.*/         
        while(row!=QUIT)
        {
            System.out.print("Enter a column >> ");
            column=input.nextInt();
            
            if(row < count.length && column<count[row].length){
                count[row][column]++;
/*This for statement declares 'r' as an int, tests for the value of 'r' against
the number of array elements in count array, after which +1 gets added to r then
is re-tested.*/                   
                for(int r=0; r < count.length; ++r){
/*This nested for statement declares the integer 'c' and tests its value against
the count array element that holds the place in which 'r's value is set. +1 is add
to c then is re-tested.*/                    
                    for(int c=0; c < count[r].length; ++c)
                        System.out.print(count[r][c] + " ");
                        System.out.println();
                }
            }

/*This else clause is set to run if the conditions in the if statement aren't met.
It simply prompts the user that they have selected an invalid position.*/               
            else 
                System.out.println("Invalid position selected");
            
            System.out.print("Enter a row or " + QUIT + " to quit >> ");
            row=input.nextInt();
        }
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
        
        }
    
}
